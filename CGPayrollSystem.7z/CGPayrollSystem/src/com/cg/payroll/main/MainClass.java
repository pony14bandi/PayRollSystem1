package com.cg.payroll.main;
import com.cg.payroll.beans.*;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {


	public static void main(String[] args) {
		PayrollServices payrollServices = new PayrollServicesImpl();
		int AssociateId=payrollServices.acceptAssociateDetails("POORNIMA", "BANDI", "IT", "SOFTWARE", "HHEOH789", "poornima@cg.com", 150000, 50000, 1000, 1000, 234545, "ICICI", "ICIC001");
		System.out.println(AssociateId);
		float y = payrollServices.calculateNetSalary(AssociateId);
		System.out.println(y);
		Associate a1=payrollServices.getAssociateDetails(AssociateId);
		System.out.println("Monthly tax= " +a1.getSalary().getMonthlyTax());
	}
}
