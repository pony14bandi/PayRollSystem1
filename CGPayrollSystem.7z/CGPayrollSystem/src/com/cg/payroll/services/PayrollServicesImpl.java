package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl implements PayrollServices{
	private PayrollDAOServices daoServices;

	public PayrollServicesImpl() {
		daoServices = new PayrollDAOServicesImpl();
	}
	@Override
	public int acceptAssociateDetails( String firstName, String lastName,String department, String designation, String pancard, String emailId,int yearlyInvestmentUnder80C ,int basicSalary,int epf,int companyPf,int accountNumber, String bankName, String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode)));
	}
	@Override
	public float calculateNetSalary(int associateId){
		float annualSalary,notTaxable,annualTax = 0;
		Associate associate = daoServices.getAssociate(associateId);
		if(associate!=null){
			float basicSalary=associate.getSalary().getBasicSalary();
			float epf = associate.getSalary().getEpf();
			float companyPf = associate.getSalary().getCompanyPf();
			float yearlyInvestment = associate.getYearlyInvestmentUnder80C();
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(basicSalary+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			annualSalary= associate.getSalary().getGrossSalary()*12;
			if((associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()<150000)) {
				if(annualSalary>=1000000) 
					annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));

				else if(annualSalary>=500000&&annualSalary<1000000) 
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf())));

				else if(annualSalary<500000 && annualSalary>=250000) 

					if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
						annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
					else 
						annualTax=0;
			}
			else if(annualSalary<250000)
				annualTax=0;
			else if(annualSalary>=1000000) 
				annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
			else if(annualSalary>=500000&&annualSalary<1000000)
				annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
			else if(annualSalary<500000 && annualSalary>=250000)
				if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
					annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
				else 
					annualTax=0;
			else
				annualTax=0;
		}
		associate.getSalary().setMonthlyTax(annualTax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		return associate.getSalary().getNetSalary();

	}

	@Override
	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);
	}
	@Override
	public Associate[] getAllAssociateDetails(){
		return daoServices.getAssociates();
	}
}

